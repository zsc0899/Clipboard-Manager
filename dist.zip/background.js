"use strict";
// 初始化存储
chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.local.get(['clipboardHistory'], (result) => {
        if (!result.clipboardHistory) {
            chrome.storage.local.set({ clipboardHistory: [] });
        }
    });
});
// 消息监听（所有按钮功能的核心）
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    switch (message.type) {
        // 添加记录
        case 'ADD_CLIPBOARD':
            chrome.storage.local.get(['clipboardHistory', 'isPro'], (result) => {
                const history = result.clipboardHistory || [];
                const isPro = !!result.isPro;
                const MAX_FREE = 3; // 免费版最多3条
                // 去重
                const isDuplicate = history.some(item => item.content === message.content);
                if (isDuplicate) {
                    sendResponse({ status: 'duplicate' });
                    return;
                }
                // 创建新记录
                const newRecord = {
                    id: Date.now().toString(),
                    content: message.content,
                    timestamp: Date.now(),
                    type: message.content.startsWith('http') ? 'link' : 'text',
                    pinned: false
                };
                // 免费版限制数量
                let newHistory = [newRecord, ...history];
                if (!isPro && newHistory.length > MAX_FREE) {
                    newHistory = newHistory.slice(0, MAX_FREE);
                }
                // 保存
                chrome.storage.local.set({ clipboardHistory: newHistory }, () => {
                    sendResponse({ status: 'success' });
                });
            });
            return true;
        // 获取记录
        case 'GET_HISTORY':
            chrome.storage.local.get(['clipboardHistory'], (result) => {
                const history = result.clipboardHistory || [];
                // 排序：置顶的在前，最新的在前
                const sortedHistory = [...history].sort((a, b) => {
                    if (a.pinned && !b.pinned)
                        return -1;
                    if (!a.pinned && b.pinned)
                        return 1;
                    return b.timestamp - a.timestamp;
                });
                sendResponse({ history: sortedHistory });
            });
            return true;
        // 删除单条记录
        case 'DELETE_RECORD':
            chrome.storage.local.get(['clipboardHistory'], (result) => {
                const history = result.clipboardHistory || [];
                const newHistory = history.filter(item => item.id !== message.id);
                chrome.storage.local.set({ clipboardHistory: newHistory }, () => {
                    sendResponse({ status: 'success' });
                });
            });
            return true;
        // 清空所有记录
        case 'CLEAR_ALL':
            chrome.storage.local.set({ clipboardHistory: [] }, () => {
                sendResponse({ status: 'success' });
            });
            return true;
        // 置顶/取消置顶
        case 'PIN_RECORD':
            chrome.storage.local.get(['clipboardHistory'], (result) => {
                const history = result.clipboardHistory || [];
                const newHistory = history.map(item => item.id === message.id ? { ...item, pinned: message.pinned } : item);
                chrome.storage.local.set({ clipboardHistory: newHistory }, () => {
                    sendResponse({ status: 'success' });
                });
            });
            return true;
        // 编辑记录
        case 'EDIT_RECORD':
            chrome.storage.local.get(['clipboardHistory'], (result) => {
                const history = result.clipboardHistory || [];
                const newHistory = history.map(item => item.id === message.id ? { ...item, content: message.content, timestamp: Date.now() } : item);
                chrome.storage.local.set({ clipboardHistory: newHistory }, () => {
                    sendResponse({ status: 'success' });
                });
            });
            return true;
        default:
            sendResponse({ status: 'error', message: 'Unknown command' });
    }
});
