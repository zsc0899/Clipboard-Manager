"use strict";
// 配置项：替换为你的购买页面URL
const BUY_URL = "https://gianfran14.gumroad.com/l/yfpvlby"; // 👉 这里修改为你的实际购买链接
// 固定激活码列表
const VALID_CODES = [
    "6F0E4C97-B72A4E69-A11BF6C4-AF6517E7",
    "James_Test"
];
// 命名空间隔离，避免重复声明
var ActivateUtils;
(function (ActivateUtils) {
    // 提示框
    ActivateUtils.showToast = (message, isSuccess = true) => {
        const toast = document.createElement('div');
        toast.className = `toast`;
        toast.style.backgroundColor = isSuccess ? '#22c55e' : '#ef4444';
        toast.style.color = 'white';
        toast.style.padding = '8px 16px';
        toast.style.borderRadius = '4px';
        toast.style.position = 'fixed';
        toast.style.bottom = '20px';
        toast.style.left = '50%';
        toast.style.transform = 'translateX(-50%)';
        toast.style.opacity = '0';
        toast.style.transition = 'opacity 0.3s ease';
        toast.textContent = message;
        document.body.appendChild(toast);
        setTimeout(() => toast.style.opacity = '1', 10);
        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => toast.remove(), 300);
        }, 2000);
    };
    // 验证激活码（替换includes为indexOf，兼容旧版ES）
    ActivateUtils.verifyCode = (code) => {
        const normalizedCode = code.trim().toUpperCase();
        // 用indexOf替代includes，避免ES版本问题
        return VALID_CODES.findIndex(item => item === normalizedCode) !== -1;
    };
    // 打开购买页面
    ActivateUtils.openBuyPage = () => {
        window.open(BUY_URL, '_blank'); // 在新标签页打开
    };
})(ActivateUtils || (ActivateUtils = {}));
// 页面初始化
document.addEventListener('DOMContentLoaded', () => {
    const codeInput = document.getElementById('activation-code');
    const activateBtn = document.getElementById('activate-btn');
    const backBtn = document.getElementById('back-btn');
    // 新增：购买按钮和链接
    const buyCodeBtn = document.getElementById('buy-code-btn');
    const buyLink = document.getElementById('buy-link');
    // 激活按钮
    activateBtn.onclick = () => {
        const code = codeInput.value.trim();
        if (!code) {
            ActivateUtils.showToast('Please enter activation code!', false);
            return;
        }
        if (ActivateUtils.verifyCode(code)) {
            // 标记为Pro用户
            chrome.storage.local.set({
                isPro: true,
                proActivated: new Date().toISOString()
            }, () => {
                ActivateUtils.showToast('Pro activated successfully!');
                setTimeout(() => window.location.href = 'index.html', 2000);
            });
        }
        else {
            ActivateUtils.showToast('Invalid activation code!', false);
        }
    };
    // 新增：购买激活码按钮点击事件
    buyCodeBtn.onclick = () => {
        ActivateUtils.openBuyPage();
    };
    // 新增：文字链接点击事件
    buyLink.onclick = (e) => {
        e.preventDefault(); // 阻止默认行为
        ActivateUtils.openBuyPage();
    };
    // 返回主页面
    backBtn.onclick = () => {
        window.location.href = 'index.html';
    };
    // Enter键激活
    codeInput.onkeydown = (e) => {
        if (e.key === 'Enter')
            activateBtn.click();
    };
});
