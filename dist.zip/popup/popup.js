"use strict";
// 命名空间隔离，避免重复声明
var PopupUtils;
(function (PopupUtils) {
    // 提示框函数
    PopupUtils.showToast = (message, isSuccess = true) => {
        // 移除旧提示
        const oldToast = document.getElementById('toast-notification');
        if (oldToast)
            oldToast.remove();
        // 创建新提示
        const toast = document.createElement('div');
        toast.id = 'toast-notification';
        toast.textContent = message;
        toast.style.backgroundColor = isSuccess ? '#22c55e' : '#ef4444';
        document.body.appendChild(toast);
        // 显示动画
        setTimeout(() => toast.style.opacity = '1', 10);
        // 自动消失
        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => toast.remove(), 300);
        }, 2000);
    };
    // 格式化时间
    PopupUtils.formatTime = (timestamp) => {
        const now = Date.now();
        const diff = now - timestamp;
        const minutes = Math.floor(diff / 60000);
        const hours = Math.floor(diff / 3600000);
        if (minutes < 1)
            return 'Just now';
        if (minutes < 60)
            return `${minutes} mins ago`;
        if (hours < 24)
            return `${hours} hrs ago`;
        return new Date(timestamp).toLocaleDateString();
    };
})(PopupUtils || (PopupUtils = {}));
// 渲染记录列表
const renderHistory = (searchKeyword = '') => {
    // 发送消息获取记录
    chrome.runtime.sendMessage({ type: 'GET_HISTORY' }, (response) => {
        const history = response?.history || [];
        const container = document.getElementById('history-container');
        container.innerHTML = '';
        // 空状态
        if (history.length === 0) {
            container.innerHTML = '<p class="empty-state">No records yet</p>';
            return;
        }
        // 搜索过滤
        const filteredHistory = searchKeyword
            ? history.filter(item => item.content.toLowerCase().includes(searchKeyword.toLowerCase()))
            : history;
        // 渲染每条记录
        filteredHistory.forEach(record => {
            const recordEl = document.createElement('div');
            recordEl.className = `record-item ${record.pinned ? 'bg-yellow-50' : ''}`;
            // 头部：置顶按钮 + 时间
            const header = document.createElement('div');
            header.className = 'record-header';
            // 置顶按钮
            const pinBtn = document.createElement('button');
            pinBtn.className = `pin-btn ${record.pinned ? 'text-red-500' : ''}`;
            pinBtn.textContent = '📌';
            pinBtn.title = record.pinned ? 'Unpin' : 'Pin';
            // 绑定点击事件（核心：用onclick确保生效）
            pinBtn.onclick = () => {
                chrome.runtime.sendMessage({ type: 'PIN_RECORD', id: record.id, pinned: !record.pinned }, () => {
                    renderHistory(searchKeyword);
                    PopupUtils.showToast(record.pinned ? 'Unpinned' : 'Pinned');
                });
            };
            // 时间戳
            const timeEl = document.createElement('span');
            timeEl.className = 'timestamp';
            timeEl.textContent = PopupUtils.formatTime(record.timestamp);
            header.append(pinBtn, timeEl);
            // 内容输入框
            const contentEl = document.createElement('div');
            contentEl.className = 'record-content';
            const contentInput = document.createElement('textarea');
            contentInput.className = `content-input ${record.type === 'link' ? 'text-blue-500' : ''}`;
            contentInput.value = record.content;
            contentInput.disabled = true;
            contentInput.style.height = '36px';
            contentEl.append(contentInput);
            // 操作按钮栏
            const actions = document.createElement('div');
            actions.className = 'record-actions';
            // 编辑按钮
            const editBtn = document.createElement('button');
            editBtn.className = 'edit-btn';
            editBtn.textContent = 'Edit';
            editBtn.onclick = () => {
                if (contentInput.disabled) {
                    contentInput.disabled = false;
                    contentInput.focus();
                    editBtn.textContent = 'Save';
                }
                else {
                    const newContent = contentInput.value.trim();
                    if (!newContent) {
                        PopupUtils.showToast('Content cannot be empty!', false);
                        return;
                    }
                    chrome.runtime.sendMessage({ type: 'EDIT_RECORD', id: record.id, content: newContent }, () => {
                        contentInput.disabled = true;
                        editBtn.textContent = 'Edit';
                        renderHistory(searchKeyword);
                        PopupUtils.showToast('Edited successfully');
                    });
                }
            };
            // 复制按钮
            const copyBtn = document.createElement('button');
            copyBtn.className = 'copy-btn';
            copyBtn.textContent = 'Copy';
            copyBtn.onclick = async () => {
                await navigator.clipboard.writeText(record.content);
                copyBtn.textContent = 'Copied!';
                PopupUtils.showToast('Copied to clipboard');
                setTimeout(() => copyBtn.textContent = 'Copy', 1000);
            };
            // 删除按钮
            const deleteBtn = document.createElement('button');
            deleteBtn.className = 'delete-btn';
            deleteBtn.textContent = 'Delete';
            deleteBtn.onclick = () => {
                if (confirm('Are you sure to delete?')) {
                    chrome.runtime.sendMessage({ type: 'DELETE_RECORD', id: record.id }, () => {
                        renderHistory(searchKeyword);
                        PopupUtils.showToast('Record deleted');
                    });
                }
            };
            actions.append(editBtn, copyBtn, deleteBtn);
            recordEl.append(header, contentEl, actions);
            container.append(recordEl);
        });
    });
};
// 页面初始化
document.addEventListener('DOMContentLoaded', () => {
    // 获取DOM元素
    const pasteInput = document.getElementById('paste-input');
    const addBtn = document.getElementById('add-btn');
    const searchInput = document.getElementById('search-input');
    const clearAllBtn = document.getElementById('clear-all-btn');
    const activateProBtn = document.getElementById('activate-pro-btn');
    // 添加记录按钮
    addBtn.onclick = () => {
        const content = pasteInput.value.trim();
        if (!content) {
            PopupUtils.showToast('Please enter content!', false);
            return;
        }
        chrome.runtime.sendMessage({ type: 'ADD_CLIPBOARD', content }, (response) => {
            if (response?.status === 'success') {
                pasteInput.value = '';
                renderHistory();
                PopupUtils.showToast('Added successfully');
            }
            else if (response?.status === 'duplicate') {
                PopupUtils.showToast('Duplicate record!', false);
            }
        });
    };
    // 搜索框防抖
    let searchTimer;
    searchInput.oninput = () => {
        clearTimeout(searchTimer);
        searchTimer = setTimeout(() => {
            renderHistory(searchInput.value.trim());
        }, 300);
    };
    // 清空所有按钮
    clearAllBtn.onclick = () => {
        if (confirm('Clear all records? This cannot be undone!')) {
            chrome.runtime.sendMessage({ type: 'CLEAR_ALL' }, () => {
                renderHistory();
                PopupUtils.showToast('All records cleared');
            });
        }
    };
    // 激活Pro按钮
    activateProBtn.onclick = () => {
        window.location.href = 'pro-activate.html';
    };
    // 初始渲染
    renderHistory();
});
